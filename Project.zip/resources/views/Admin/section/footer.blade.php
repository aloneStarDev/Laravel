    </div>
</div>

<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<style>
    .req{
        border-right: 5px solid red;
    }
    .uin{
        border-right: 2px solid green;
    }
</style>
<script src="/js/admin.js"></script>
<script src="/js/bootstrap-select.min.js"></script>
