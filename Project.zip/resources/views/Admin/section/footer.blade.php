    </div>
</div>

<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->

<script src="/js/admin.js"></script>
<script src="/js/bootstrap-select.min.js"></script>
