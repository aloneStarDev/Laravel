<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateFilesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('files', function (Blueprint $table) {
            $table->integerIncrements('fileId');
            $table->string('name');
            $table->string('lastname');
            $table->string('phonenumber',20)->unique();
            $table->string('addressPu');//public Address
            $table->string('addressPv');//private Address
            $table->string('imgPath')->nullable();
            $table->integer('region');
            $table->integer('user_id');//how employee stored this file
            $table->boolean('visible')->default(true);
            $table->boolean('enable')->default(true);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('files');
    }
}
