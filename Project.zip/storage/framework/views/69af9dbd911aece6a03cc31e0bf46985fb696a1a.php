<?php echo $__env->make('template.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<form action="<?php echo e(route('resetPassword')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <label for="phone">لطفا شماره تماس را وارد کنید</label>
    <input type="text" id="phone" name="phonenumber" placeholder="phonenumber" />
    <input type="submit" value="send">
</form>
<?php echo $__env->make('template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH E:\wamp64\www\Project\resources\views/Auth/forget.blade.php ENDPATH**/ ?>