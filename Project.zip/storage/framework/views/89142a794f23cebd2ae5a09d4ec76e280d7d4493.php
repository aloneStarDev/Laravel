<style>
    li:hover{
        cursor: pointer;
    }
</style>
<?php $__env->startSection('content'); ?>
    <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
        <div class="page-header head-section">
            <h2>نمایش</h2>
        </div>
        <div>
            <?php echo $__env->make('Admin.section.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="row">
                <label class="control-label">نام و نام خانوادگی مالک</label>
                <div class="text-primary"><?php echo e($receive->name); ?> <?php echo e($receive->lastname); ?></div>
            </div>
            <div class="row">
                <label class="control-label">نوع ملک</label>
                <div class="text-primary"><?php echo e(\App\File::$bulbing_type[$receive->buildingType]); ?></div>
            </div>
            <div class="row">
                <label class="control-label">آدرس</label>
                <div class="text-primary"><?php echo e($receive->address); ?></div>
            </div>
            <div class="row">
                <label class="control-label">شماره تماس</label>
                <div class="text-primary"><?php echo e($receive->phonenumber); ?></div>
            </div>
            <?php if($receive->description != null): ?>
            <div class="row">
                <label class="control-label">توضیحات</label>
                <div class="text-primary"><?php echo e($receive->description); ?></div>
            </div>
            <?php endif; ?>
            <div class="form-group">
                <div class="col-sm-12">
                    <a href="<?php echo e(route("received",$receive->type)); ?>" class="btn btn-danger">بازگشت</a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\Project\resources\views/Admin/received/show.blade.php ENDPATH**/ ?>