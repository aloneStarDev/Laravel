<?php $__env->startSection('content'); ?>
    <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
        <div class="page-header head-section">
            <h2>ایجاد کارمند</h2>
        </div>
        <form class="form-horizontal" action="<?php echo e(route('agents.store')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo $__env->make('Admin.section.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="form-group">
                <div class="col-sm-12">
                    <label for="name" class="control-label">نام</label>
                    <input type="text" class="form-control" name="name" id="name" placeholder="نام را وارد کنید" value="<?php echo e(old('name')); ?>">
                </div>
            </div>

            <div class="form-group">
                <div class="col-sm-12">
                    <label for="lastname" class="control-label">نام خانوادگی</label>
                    <input type="text" class="form-control" name="lastname" id="lastname" placeholder="نام خانوادگی را وارد کنید" value="<?php echo e(old('lastname')); ?>">
                </div>
            </div>

            <div class="form-group">
                <div class="col-sm-12">
                    <label for="phonenumber" class="control-label">شماره تلفن</label>
                    <input type="text" class="form-control" name="phonenumber" id="phonenumber" placeholder="شماره تلفن را وارد کنید" value="<?php echo e(old('phonenumber')); ?>">
                </div>
            </div>

            <div class="form-group">
                <div class="col-sm-12">
                    <label for="nationCode" class="control-label">کدملی</label>
                    <input type="text" class="form-control" name="nationCode" id="nationCode" placeholder="کدملی را وارد کنید" value="<?php echo e(old('nationCode')); ?>">
                </div>
            </div>

            <div class="form-group">
                <div class="col-sm-12">
                    <label for="address" class="control-label">آدرس</label>
                    <textarea rows="5" class="form-control" name="address" id="address" placeholder="آدرس را وارد کنید"><?php echo e(old('address')); ?></textarea>
                </div>
            </div>

            <div class="form-group">
                <div class="col-sm-12">
                    <button type="submit" class="btn btn-danger">ارسال</button>
                </div>
            </div>

        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\Project\resources\views/Admin/agents/create.blade.php ENDPATH**/ ?>