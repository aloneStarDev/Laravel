<?php $__env->startSection('content'); ?>
    <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
        <div class="page-header head-section">
            <h2>ویرایش کارمند</h2>
        </div>
        <form class="form-horizontal" action="<?php echo e(route('agents.update', ['agent' => $agent->id])); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo $__env->make('Admin.section.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo method_field('patch'); ?>
            <div class="form-group">
                <div class="col-sm-12">
                    <label for="name" class="control-label">نام</label>
                    <input type="text" class="form-control" name="name" id="name" placeholder="نام را وارد کنید" value="<?php echo e($agent->name); ?>">
                </div>
            </div>

            <div class="form-group">
                <div class="col-sm-12">
                    <label for="lastname" class="control-label">نام خانوادگی</label>
                    <input type="text" class="form-control" name="lastname" id="lastname" placeholder="نام خانوادگی را وارد کنید" value="<?php echo e($agent->lastname); ?>">
                </div>
            </div>

            <div class="form-group">
                <div class="col-sm-12">
                    <label for="phonenumber" class="control-label">شماره تلفن</label>
                    <input type="text" class="form-control" name="phonenumber" id="phonenumber" placeholder="شماره تلفن را وارد کنید" value="<?php echo e($agent->phonenumber); ?>">
                </div>
            </div>

            <div class="form-group">
                <div class="col-sm-12">
                    <label for="nationCode" class="control-label">کدملی</label>
                    <input type="text" class="form-control" name="nationCode" id="nationCode" placeholder="کدملی را وارد کنید" value="<?php echo e($agent->nationCode); ?>">
                </div>
            </div>

            <div class="form-group">
                <div class="col-sm-12">
                    <label for="active" class="control-label">وضعیت</label>
                    <input type="checkbox" class="checkbox-inline" onclick="f()" <?php if($agent->active == 1): ?> checked="true" <?php endif; ?> >
                    <script>
                        function f() {
                            let active = 0;
                            <?php if($agent->active): ?>
                                active = 0;
                            <?php else: ?>
                                active = 1;
                            <?php endif; ?>
                            document.getElementById('active').value = active;
                        }
                    </script>
                    <input type="hidden" id="active" name="active" value="<?php echo e($agent->active); ?>">
                </div>
            </div>

            <div class="form-group">
                <div class="col-sm-12">
                    <label for="address" class="control-label">آدرس</label>
                    <textarea rows="5" class="form-control" name="address" id="address" placeholder="آدرس را وارد کنید"><?php echo e($agent->address); ?></textarea>
                </div>
            </div>

            <div class="form-group">
                        <div class="col-sm-12">
                    <button type="submit" class="btn btn-success">ویرایش</button>

                    <a href="<?php echo e(route("agents.index")); ?>" class="btn btn-danger">بازگشت</a>
                </div>
            </div>

        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\Project\resources\views/Admin/agents/edit.blade.php ENDPATH**/ ?>