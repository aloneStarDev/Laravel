<div class="cell" <?php if($i % 3 == 1): ?> style="margin-right:2%;" <?php endif; ?> >
    <img alt="house" src="../base/images/city_illustrations_empire_state_building_2x.png"
         class="house-image">
    <h3 class="cell-h3">
        <?php echo e(\App\File::$bulbing_type[$files[$i]->buildingType]); ?>  <?php echo e($files[$i]->area); ?>متری
    </h3>
    <div class="cell-content">
      <span class="cell-type">
      <i class="fas fa-home"></i>
        <?php echo e(\App\File::$bulbing_type[$files[$i]->buildingType]); ?>

      </span>
        <span class="cell-metre">
      <i class="fas fa-expand"></i>
      متر <?php echo e($files[$i]->area); ?>

      </span>
        <span class="cell-beds">
      <i class="fas fa-bed"></i>
      <?php echo e($files[$i]->bedroom); ?> خوابه
      </span>
        <span class="cell-address">
      <i class="fas fa-map-marker-alt"></i>
      <?php echo e($files[$i]->addressPu); ?>

      </span>
        <?php if($files[$i]->rahn != null): ?>
            <span class="cell-year">
      رهن : <?php echo e(\App\File::floatPrice($files[$i]->rahn)); ?>

      </span>
        <?php else: ?>
            <?php if($files[$i]->ejare != null): ?>
                <span class="cell-month">
          اجاره: <?php echo e(\App\File::floatPrice($files[$i]->ejare)); ?>

          </span>
            <?php endif; ?>
            <?php if($files[$i]->buy != null): ?>
                <span class="cell-month">
          خرید: <?php echo e(\App\File::floatPrice($files[$i]->buy)); ?>

          </span>
            <?php endif; ?>
        <?php endif; ?>
        <a href="<?php echo e(route("info",$files[$i]->id)); ?>">
            <button class="btn cell-btn" style="margin-left:10%;">
                جزئیات
            </button>
        </a>
        <a href="tel:09304437593">
            <button class="btn cell-btn">
                تماس
                <i class="fas fa-phone"></i>
            </button>
        </a>
    </div>
</div>
<?php /**PATH E:\wamp64\www\Project\resources\views/Base/section/fileItem.blade.php ENDPATH**/ ?>