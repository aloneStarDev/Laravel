<style>
    li:hover{
        cursor: pointer;
    }
</style>
<?php $__env->startSection('content'); ?>
    <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
        <div class="page-header head-section">
            <h2>نمایش</h2>
        </div>
        <div>
            <?php echo $__env->make('Admin.section.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php if($file->buy != null): ?>
            <div class="row">
                <label class="control-label">هزینه ی خرید</label>
                <div class="text-primary"> <?php echo e(\App\File::floatPrice($file->buy)); ?> </div>
            </div>
            <?php endif; ?>
            <?php if($file->rahn != null): ?>
            <div class="row">
                <label class="control-label">هزینه ی رهن</label>
                <div class="text-primary"><?php echo e(\App\File::floatPrice($file->rahn)); ?></div>
            </div>
            <?php endif; ?>
            <?php if($file->ejare != null): ?>
            <div class="row">
                <label class="control-label">هزینه ی اجاره </label>
                <div class="text-primary"><?php echo e(\App\File::floatPrice($file->ejare)); ?></div>
            </div>
            <?php endif; ?>

            <div class="row">
                <label class="control-label">نام و نام خانوادگی مالک</label>
                <div class="text-primary"><?php echo e($file->name); ?> <?php echo e($file->lastname); ?></div>
            </div>
            <div class="row">
                <label class="control-label">نوع ساختمان</label>
                <div class="text-primary"><?php echo e(\App\File::$bulbing_type[$file->buildingType]); ?></div>
            </div>
            <?php if($file->floor): ?>
            <div class="row">
                <label class="control-label">طبقه</label>
                <div class="text-primary"><?php echo e($file->floor); ?></div>
            </div>
            <?php endif; ?>
            <div class="row">
                <label class="control-label">متراژ</label>
                <div class="text-primary"><?php echo e($file->area); ?></div>
            </div>

            <?php if($file->age): ?>
            <div class="row">
                <label class="control-label">سن بنا</label>
                <div class="text-primary"><?php echo e($file->age); ?></div>
            </div>
            <?php endif; ?>

            <?php if($file->unit): ?>
            <div class="row">
                <label class="control-label">تعداد واحد</label>
                <div class="text-primary"><?php echo e($file->unit); ?></div>
            </div>
            <?php endif; ?>
            <?php if($file->bedroom): ?>
            <div class="row">
                <label class="control-label">تعداد خواب</label>
                <div class="text-primary"><?php echo e($file->bedroom); ?></div>
            </div>
            <?php endif; ?>
            <div class="row">
                <label class="control-label">منطقه</label>
                <div class="text-primary"><?php echo e(\App\File::$region_map[$file->region]); ?></div>
            </div>
            <div class="row">
                <label class="control-label">آدرس اصلی</label>
                <div class="text-primary"><?php echo e($file->addressPu); ?></div>
            </div>
            <div class="row">
                <label class="control-label">آدرس فرعی</label>
                <div class="text-primary"><?php echo e($file->addressPv); ?></div>
            </div>
            <div class="row">
                <label class="control-label">شماره تماس</label>
                <div class="text-primary"><?php echo e($file->phonenumber); ?></div>
            </div>
            <?php if($file->floorCovering != 0): ?>
            <div class="row">
                <label for="floorCovering" class="control-label">کفپوش</label>
                <div class="text-primary" id="floorCovering"><?php echo e(\App\File::$floor_covering[$file->floorCovering]); ?></div>
            </div>
            <?php endif; ?>
            <?php if($file->cabinet != 0): ?>
                <div class="row">
                    <label for="cabinet" class="control-label">کابینت</label>
                    <div class="text-primary" id="cabinet"><?php echo e(\App\File::$cabinet_[$file->cabinet]); ?></div>
                </div>
            <?php endif; ?>
            <?php if($file->floorCount != null): ?>
                <div class="row">
                    <label for="floorCount" class="control-label">تعداد طبقات</label>
                    <div class="text-primary" id="floorCount"><?php echo e($file->floorCount); ?></div>
                </div>
            <?php endif; ?>
            <?php if($file->heating != 0): ?>
                <div class="row">
                    <label for="heating" class="control-label">گرمایش</label>
                    <div class="text-primary" id="heating"><?php echo e(\App\File::$heating_[$file->heating]); ?></div>
                </div>
            <?php endif; ?>
            <?php if($file->cooling != 0): ?>
                <div class="row">
                    <label for="cooling" class="control-label">سرمایش</label>
                    <div class="text-primary" id="cooling"><?php echo e(\App\File::$heating_[$file->cooling]); ?></div>
                </div>
            <?php endif; ?>
            <?php if($file->view != 0): ?>
                <div class="row">
                    <label for="view" class="control-label">نما</label>
                    <div class="text-primary" id="view"><?php echo e(\App\File::$view_[$file->view]); ?></div>
                </div>
            <?php endif; ?>
            <?php if($file->document != 0): ?>
                <div class="row">
                    <label for="document" class="control-label">سند</label>
                    <div class="text-primary" id="document"><?php echo e(\App\File::$document_[$file->document]); ?></div>
                </div>
            <?php endif; ?>
            <?php if($file->description != null): ?>
            <div class="row">
                <label class="control-label">توضیحات</label>
                <div class="text-primary"><?php echo e($file->description); ?></div>
            </div>
            <?php endif; ?>
            <div class="form-group">
                <div class="col-sm-12">
                    <a href="<?php echo e(route("files.index")); ?>" class="btn btn-danger">بازگشت</a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\Project\resources\views/Admin/files/show.blade.php ENDPATH**/ ?>