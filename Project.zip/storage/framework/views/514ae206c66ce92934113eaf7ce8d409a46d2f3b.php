<style>
    li:hover{
        cursor: pointer;
    }
</style>
<?php $__env->startSection('content'); ?>
    <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
        <div class="page-header head-section">
            <h2>نمایش</h2>
        </div>
        <div>
            <?php echo $__env->make('Admin.section.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="row">
                <label class="control-label">هزینه ی خرید</label>
                <div class="text-primary"> <?php echo e(floor($file->buy)); ?> میلیون <?php if((($file->buy) - floor($file->buy)) != 0): ?> و <?php echo e(((($file->buy) - floor($file->buy))*1000)); ?> هزار تومان <?php else: ?> تومان <?php endif; ?> </div>
            </div>
            <div class="row">
                <label class="control-label">هزینه ی رهن</label>
                <div class="text-primary"><?php echo e(floor($file->rahn)); ?> میلیون <?php if((($file->rahn) - floor($file->buy)) != 0): ?> و <?php echo e(((($file->rahn) - floor($file->rahn))*1000)); ?> هزار تومان <?php else: ?> تومان <?php endif; ?></div>
            </div>

            <div class="row">
                <label class="control-label">هزینه ی اجاره </label>
                <div class="text-primary"><?php echo e(floor($file->ejare)); ?> میلیون <?php if((($file->ejare) - floor($file->ejare)) != 0): ?> و <?php echo e(((($file->ejare) - floor($file->ejare))*1000)); ?> هزار تومان <?php else: ?> تومان <?php endif; ?></div>
            </div>

            <div class="row">
                <label class="control-label">نام و نام خانوادگی مالک</label>
                <div class="text-primary"><?php echo e($file->lastname); ?> <?php echo e($file->name); ?></div>
            </div>
            <div class="row">
                <label class="control-label">نوع ساختمان</label>
                <div class="text-primary"><?php echo e(\App\File::$bulbing_type[$file->buildingType]); ?></div>
            </div>
            <div class="row">
                <label class="control-label">طبقه</label>
                <div class="text-primary"><?php echo e($file->floor); ?></div>
            </div>
            <div class="row">
                <label class="control-label">متراژ</label>
                <div class="text-primary"><?php echo e($file->area); ?></div>
            </div>
            <div class="row">
                <label class="control-label">سن بنا</label>
                <div class="text-primary"><?php echo e($file->age); ?></div>
            </div>
            <div class="row">
                <label class="control-label">تعداد واحد</label>
                <div class="text-primary"><?php echo e($file->unit); ?></div>
            </div>
            <div class="row">
                <label class="control-label">تعداد خواب</label>
                <div class="text-primary"><?php echo e($file->bedroom); ?></div>
            </div>
            <div class="row">
                <label class="control-label">منطقه</label>
                <div class="text-primary"><?php echo e(\App\File::$region_map[$file->region]); ?></div>
            </div>
            <div class="row">
                <label class="control-label">آدرس اصلی</label>
                <div class="text-primary"><?php echo e($file->addressPu); ?></div>
            </div>
            <div class="row">
                <label class="control-label">آدرس فرعی</label>
                <div class="text-primary"><?php echo e($file->addressPv); ?></div>
            </div>
            <div class="row">
                <label class="control-label">شماره تماس</label>
                <div class="text-primary"><?php echo e($file->phonenumber); ?></div>
            </div>
            <div class="row">
                <label class="control-label">جزئیات</label>
                <ul id="boolOption">

                </ul>

                <ul id="textOption">

                </ul>
            </div>
            <div class="row">
                <label class="control-label">توضیحات</label>
                <div class="text-primary"><?php echo e($file->description); ?></div>
            </div>
            <div class="form-group">
                <div class="col-sm-12">
                    <a href="<?php echo e(route("files.index")); ?>" class="btn btn-danger">بازگشت</a>
                </div>
            </div>
        </div>
    </div>
    <script>
        let options = JSON.parse(<?php echo json_encode($file->options, 15, 512) ?>);
        if(options != null ){
            if(options.hasOwnProperty('options1'))
                options.options1.forEach(function (key) {
                    let keyset = Object.keys(key);
                    var node = document.createElement("LI");
                    node.id = keyset[0];
                    var textNode = document.createTextNode(keyset + " : " + (key[keyset] ? "دارد": "ندارد"));
                    node.appendChild(textNode);
                    document.getElementById("boolOption").appendChild(node);
                });
            if(options.hasOwnProperty('options2'))
                options.options2.forEach(function (key) {
                    let keyset = Object.keys(key);
                    var node = document.createElement("LI");
                    node.id = keyset[0];
                    var textNode = document.createTextNode(keyset + " : " + key[keyset] );
                    node.appendChild(textNode);
                    document.getElementById("textOption").appendChild(node);
                })
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\Project\resources\views/Admin/files/show.blade.php ENDPATH**/ ?>