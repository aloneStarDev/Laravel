<?php $__env->startSection('content'); ?>
    <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
        <div class="page-header head-section">
            <h2>کارمندان</h2>
            <a href="<?php echo e(route('agents.create')); ?>" class="btn btn-sm btn-primary">ایجاد کارمند</a>
        </div>
        <div class="table-responsive">
            <table class="table table-striped table-bordered">
                <thead>
                <tr>
                    <th>نام</th>
                    <th>تلفن</th>
                    <th>کد ملی</th>
                    <th>رمز عبور</th>
                    <th>آدرس</th>
                    <th>تعداد ثبتی</th>
                    <th>وضعیت</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($agent->name); ?> <?php echo e($agent->lastname); ?></td>
                        <td><?php echo e($agent->phonenumber); ?></td>
                        <td><?php echo e($agent->nationCode); ?></td>
                        <td><a href="#" class="btn btn-info">تغیرر رمز عبور</a></td>
                        <td><?php echo e($agent->address); ?></td>
                        <td><?php echo e($agent->registered_items); ?></td>
                        <td><?php if($agent->active==1): ?> فعال <?php else: ?> غیر فعال <?php endif; ?></td>
                        <td>
                            <form action="<?php echo e(route('agents.destroy', ['agent' => $agent->id])); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <div class="btn-group btn-group-xs">
                                    <a href="<?php echo e(route('agents.edit', ['agent' => $agent->id])); ?>" class="btn btn-primary">ویرایش</a>
                                    <button type="submit" class="btn btn-danger">حذف</button>
                                </div>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div style="text-align: center">
            <?php echo $agents->render(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\Project\resources\views/Admin/agents/all.blade.php ENDPATH**/ ?>