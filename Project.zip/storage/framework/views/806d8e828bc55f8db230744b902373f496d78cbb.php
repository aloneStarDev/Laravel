<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('Admin.section.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
        <div class="page-header head-section">
            <h2>اعلام مغایرت</h2>
        </div>
        <div class="row">
            <a href="<?php echo e(route('file.callback',["file"=>json_encode($file),'mode'=>$mode])); ?>" class="btn  btn-success">نادیده گرفتن و ثبت</a>
            <a href="<?php echo e(route('file.callback',["file"=>json_encode($file),'mode'=>($mode+2)])); ?>" class="btn  btn-default">بازگشت و ویرایش</a>
        </div>
        <div class="table-responsive">
            <table class="table table-striped table-bordered">
                <thead>
                <tr>
                    <th>نام و نام خانوادگی</th>
                    <th>تلفن</th>
                    <th>آدرس اصلی</th>
                    <th>آدرس فرعی</th>
                    <th>ناحیه</th>
                    <th>کد فایل</th>
                    <th>نوع مغایرت</th>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("master")): ?>
                            <th>کنترل</th>
                    <?php endif; ?>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $filesN; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($f->name); ?> <?php echo e($f->lastname); ?></td>
                        <td><?php echo e($f->phonenumber); ?></td>
                        <td><?php echo e($f->addressPu); ?></td>
                        <td><?php echo e($f->addressPv); ?></td>
                        <td><?php echo e($f->region); ?></td>
                        <td><?php echo e($f->code); ?></td>
                        <td> نام و نام خانوادگی </td>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('master')): ?>
                        <td>
                            <div class="btn-group btn-group-xs">
                                <form action="<?php echo e(route('files.destroy', $f)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button type="submit" class="btn btn-default">حذف</button>
                                    <a href="<?php echo e(route('files.edit', $f)); ?>" class="btn btn-default">ویرایش</a>
                                    <a href="<?php echo e(route('changeMode', $f)); ?>" class="btn btn-default">تغییر وضعیت</a>
                                    <a href="<?php echo e(route('archive',$f)); ?>" class="btn btn-default">بایگانی</a>
                                    <a href="<?php echo e(route('files.show',$f)); ?>" class="btn btn-default">نمایش جزئیات</a>
                                </form>
                            </div>
                        </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php $__currentLoopData = $filesP; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($f->name); ?> <?php echo e($f->lastname); ?></td>
                        <td><?php echo e($f->phonenumber); ?></td>
                        <td><?php echo e($f->addressPu); ?></td>
                        <td><?php echo e($f->addressPv); ?></td>
                        <td><?php echo e($f->region); ?></td>
                        <td><?php echo e($f->code); ?></td>
                        <td> شماره تماس </td>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('master')): ?>
                            <td>
                                <div class="btn-group btn-group-xs">
                                    <form action="<?php echo e(route('files.destroy', $f)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button type="submit" class="btn btn-default">حذف</button>
                                        <a href="<?php echo e(route('files.edit', $f)); ?>" class="btn btn-default">ویرایش</a>
                                        <a href="<?php echo e(route('changeMode', $f)); ?>" class="btn btn-default">تغییر وضعیت</a>
                                        <a href="<?php echo e(route('archive',$f)); ?>" class="btn btn-default">بایگانی</a>
                                        <a href="<?php echo e(route('files.show',$f)); ?>" class="btn btn-default">نمایش جزئیات</a>
                                    </form>
                                </div>
                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php $__currentLoopData = $filesA; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($f->name); ?> <?php echo e($f->lastname); ?></td>
                        <td><?php echo e($f->phonenumber); ?></td>
                        <td><?php echo e($f->addressPu); ?></td>
                        <td><?php echo e($f->addressPv); ?></td>
                        <td><?php echo e($f->region); ?></td>
                        <td><?php echo e($f->code); ?></td>
                        <td> آدرس </td>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('master')): ?>
                            <td>
                                <div class="btn-group btn-group-xs">
                                    <form action="<?php echo e(route('files.destroy', $f)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button type="submit" class="btn btn-default">حذف</button>
                                        <a href="<?php echo e(route('files.edit', $f)); ?>" class="btn btn-default">ویرایش</a>
                                        <a href="<?php echo e(route('changeMode', $f)); ?>" class="btn btn-default">تغییر وضعیت</a>
                                        <a href="<?php echo e(route('archive',$f)); ?>" class="btn btn-default">بایگانی</a>
                                        <a href="<?php echo e(route('files.show',$f)); ?>" class="btn btn-default">نمایش جزئیات</a>
                                    </form>
                                </div>
                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\Project\resources\views/Admin/files/recheck.blade.php ENDPATH**/ ?>