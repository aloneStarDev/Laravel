<?php $__env->startSection('content'); ?>
    <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
        <div class="page-header head-section">
            <h2>مشترک ها</h2>
            <a href="<?php echo e(route('members.create')); ?>" class="btn btn-sm btn-primary">ایجاد کاربر</a>
        </div>
        <div class="table-responsive">
            <table class="table table-striped table-bordered">
                <thead>
                <tr>
                    <th>عنوان</th>
                    <th>مقدار</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $customer->toArray(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($key); ?></td>
                        <td><?php echo e($val); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <a href="<?php echo e(route('members.index')); ?>">
                <button class="btn btn-danger">بازگشت</button>
            </a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\Project\resources\views/Admin/members/show.blade.php ENDPATH**/ ?>