<?php $__env->startSection('content'); ?>
    <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
        <form action="<?php echo e(route('members.update',$customer->id)); ?>" method="post">
            <?php echo method_field("patch"); ?>
            <?php echo csrf_field(); ?>
            <?php echo $__env->make("Admin.section.errors", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="form-group">
                <input dir="rtl" type="text" name="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> alert alert-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($customer->name); ?>" placeholder="نام"/>
            </div>
            <div class="form-group">
                <input dir="rtl" type="text" name="lastname" class="form-control <?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> alert alert-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($customer->lastname); ?>" placeholder="نام خانوادگی"/>
            </div>
            <div class="form-group">
                <input dir="rtl" type="text" id="phonenumber" name="phonenumber" class="form-control <?php $__errorArgs = ['phonenumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> alert alert-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($customer->phonenumber); ?>"  placeholder="شماره تماس"/>
            </div>
            <div class="form-group">
                <input dir="rtl" type="number" name="region" class="form-control <?php $__errorArgs = ['region'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> alert alert-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($customer->region); ?>" placeholder="منطقه ی شهرداری"/>
            </div>
            <div class="form-group">
                <input dir="rtl" type="email" name="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> alert alert-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($customer->email); ?>" placeholder="ایمیل"/>
            </div>
            <div class="form-group">
                <input dir="rtl" type="text" name="office" class="form-control <?php $__errorArgs = ['office'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> alert alert-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($customer->office); ?>" placeholder="نام املاکی"/>
            </div>
            <div class="form-group">
                <textarea dir="rtl" type="text" rows="5" name="address" class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> alert alert-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="آدرس"><?php echo e($customer->address); ?></textarea>
            </div>
            <div class="form-group">
                <span for="call">این شماره ی برای نمایش به مشتری است در صورتی که این فیلد را پر نکنید شماره ی همراه به کاربران نمایش داده می شود</span>
                <input id="call" dir="rtl" type="text" name="call" class="form-control <?php $__errorArgs = ['call'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> alert alert-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="شماره تماس" value="<?php echo e($customer->call); ?>" />
            </div>
            <div class="form-group">
                <span for="panel">نوع اشتراک</span>
                <select name="panel" id="panel" class="bootstrap-select form-control">
                    <option <?php if($customer->panel == 1): ?> selected="selected" <?php endif; ?> value="1">یک ماه</option>
                    <option value="2" <?php if($customer->panel == 2): ?> selected="selected" <?php endif; ?>>سه ماه</option>
                    <option value="3" <?php if($customer->panel == 3): ?> selected="selected" <?php endif; ?>>شش ماه</option>
                    <option value="4" <?php if($customer->panel == 4): ?> selected="selected" <?php endif; ?>>یک ساله</option>
                </select>
            </div>

            <div class="form-group">
                <input type="number" class="form-control" name="ipCount" value="<?php echo e($customer->ipCount); ?>" placeholder="تعداد کاربران اضافه" />
            </div>
            <div class="form-group">
                <input type="text" class="form-control" name="username" placeholder="نام کاربری" />
            </div>
            <div class="form-group">
                <input type="password" class="form-control" name="password" placeholder="گذرواژه" />
            </div>
            <div class="form-group">
                <div class="col-sm-12">
                    <button type="submit" class="btn btn-success">ارسال</button>

                    <a href="<?php echo e(route("members.index")); ?>" class="btn btn-danger">بازگشت</a>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\Project\resources\views/Admin/members/edit.blade.php ENDPATH**/ ?>