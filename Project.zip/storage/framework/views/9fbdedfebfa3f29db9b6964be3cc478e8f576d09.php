<?php echo $__env->make('template.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<form action="<?php echo e(route('verifyForget')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <label for="phone">لطفا کد تایید را وارد کنید</label>
    <input type="text" name="verify" placeholder="ActivationCode" />
    <label for="phone">لطفا رمز تایید را وارد کنید</label>
    <input type="text" name="password" placeholder="password" />
    <input type="submit" value="send">
</form>
<?php echo $__env->make('template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH E:\wamp64\www\Project\resources\views/Auth/reset.blade.php ENDPATH**/ ?>