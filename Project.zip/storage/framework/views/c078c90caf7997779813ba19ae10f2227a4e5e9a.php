<?php $__env->startSection('content'); ?>
    <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
        <div class="page-header head-section">
            <h2>درخواست ها ی ثبت شده</h2>
        </div>
        <div class="table-responsive">
            <table class="table table-striped table-bordered">
                <thead>
                <tr>
                    <th>نام</th>
                    <th>نام خانوادگی</th>
                    <th>شماره تماس</th>
                    <th>آدرس</th>
                    <th>نوع درخواست</th>
                    <th>نوع ساختمان</th>
                    <th>عملیات</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $receives; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($r->name); ?></td>
                        <td><?php echo e($r->lastname); ?></td>
                        <td><?php echo e($r->phonenumber); ?></td>
                        <td><?php echo e($r->address); ?></td>
                        <td><?php echo e(\App\Receive::$mode_[$r->mode]); ?></td>
                        <td><?php echo e(\App\File::$bulbing_type[$r->buildingType]); ?></td>
                        <td>
                            <a href="<?php echo e(route('removeReceived',$r->id)); ?>"><button class="btn btn-danger">حذف</button></a>
                            <a href="<?php echo e(route('showReceived',$r->id)); ?>"><button class="btn btn-default">نمایش</button></a>
                        <?php if($r->type==1): ?>
                            <a href="<?php echo e(route('editReceived',$r->id)); ?>"><button class="btn btn-success">ویرایش و ثبت</button></a>
                            <?php endif; ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\Project\resources\views/Admin/received/all.blade.php ENDPATH**/ ?>