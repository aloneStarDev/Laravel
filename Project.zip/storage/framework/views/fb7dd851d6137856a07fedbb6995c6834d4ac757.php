<ul class=" justify-content-end nav-pills topul">
    <?php if(auth()->guard()->check()): ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("admin","master")): ?>
            <li class="nav-item">
                <a href="<?php echo e(route("manage")); ?>" class="atag firstProf">
                    <button type="button" class="btn">
                        <i class="fas fa-chevron-right" style="margin-left:5%;"></i>
                        <span>
                       مدیرت
                     </span>
                        <i class="fas fa-plus icon"></i>
                    </button>
                </a>
            </li>
        <?php else: ?>
            <li class="nav-item">
                <a href="<?php echo e(route("member.panel")); ?>" class="atag firstProf">
                    <button type="button" class="btn">
                        <i class="fas fa-chevron-right" style="margin-left:5%;"></i>
                        <span>
                       مدیرت
                     </span>
                        <i class="fas fa-plus icon"></i>
                    </button>
                </a>
            </li>
        <?php endif; ?>
    <?php else: ?>
        <li class="nav-item">
            <a href="#" class="atag firstProf">
                <button type="button" class="btn">
                    <i class="fas fa-chevron-right" style="margin-left:5%;"></i>
                    <span>
                       ثبت آگهی رایگان
                     </span>
                    <i class="fas fa-plus icon"></i>
                </button>
            </a>
        </li>
    <?php endif; ?>
    <?php if(auth()->guard()->check()): ?>
        <li class="nav-item">
            <a class="atag secProf" href="<?php echo e(route("logout")); ?>">
                <button type="button" class="btn">
                    <i class="fas fa-chevron-right" style="margin-left:5%;"></i>
                    <span>
                        خروج حساب کاربری
                    </span>
                    <i class="fas fa-times-circle"></i>
                </button>
            </a>
        </li>
    <?php else: ?>
        <li class="nav-item">
            <a class="atag secProf">
                <button type="button" class="btn">
                    <i class="fas fa-chevron-right" style="margin-left:5%;"></i>
                    <span>
                            ورود/ثبت نام مشاورین
                            </span>
                    <i class="fas fa-user icon"></i>
                </button>
            </a>
        </li>
    <?php endif; ?>
</ul>
<?php /**PATH E:\wamp64\www\Project\resources\views/Base/section/btnMenu.blade.php ENDPATH**/ ?>