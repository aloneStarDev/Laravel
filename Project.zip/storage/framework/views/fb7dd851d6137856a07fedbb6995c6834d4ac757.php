<ul class=" justify-content-end nav-pills topul">
    <li class="nav-item">
        <a href="#" class="atag firstProf">
            <button type="button" class="btn">
                <i class="fas fa-chevron-right" style="margin-left:5%;"></i>
                <span>
                   ثبت آگهی رایگان
                 </span>
                <i class="fas fa-plus icon"></i>
            </button>
        </a>
    </li>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("customer")): ?>
        <li class="nav-item">
            <a class="atag secProf" href="<?php echo e(route("logout")); ?>">
                <button type="button" class="btn">
                    <i class="fas fa-chevron-right" style="margin-left:5%;"></i>
                    <span>
                        <?php echo e(auth()->user()->customer()->office); ?>

                    </span>
                    <i class="fas fa-times-circle"></i>
                </button>
            </a>
        </li>
    <?php else: ?>
        <li class="nav-item">
            <a class="atag secProf">
                <button type="button" class="btn">
                    <i class="fas fa-chevron-right" style="margin-left:5%;"></i>
                    <span>
                                    ورود/ثبت نام مشاورین
                                    </span>
                    <i class="fas fa-user icon"></i>
                </button>
            </a>
        </li>
    <?php endif; ?>
</ul>
<?php /**PATH E:\wamp64\www\Project\resources\views/Base/section/btnMenu.blade.php ENDPATH**/ ?>