<?php $__env->startSection('content'); ?>
    <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
        <div class="page-header head-section">
            <h2>فایل</h2>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show_files')): ?>
            <a href="<?php echo e(route('files.create')); ?>" class="btn btn-sm btn-primary">ایجاد فایل</a>
            <?php endif; ?>

        </div>
        <div class="table-responsive">
            <table class="table table-striped table-bordered">
                <thead>
                <tr>
                    <th>نام و نام خانوادگی</th>
                    <th>تلفن</th>
                    <th>آدرس اصلی</th>
                    <th>آدرس فرعی</th>
                    <th>ناحیه</th>
                    <th>نمایش تصویر</th>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("show_files")): ?>
                    <th>وضعیت</th>
                    <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("admin_permissions")): ?>
                        <th>کنترل</th>
                    <?php endif; ?>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($file->name); ?> <?php echo e($file->lastname); ?></td>
                        <td><?php echo e($file->phonenumber); ?></td>
                        <td><?php echo e($file->addressPu); ?></td>
                        <td><?php echo e($file->addressPv); ?></td>
                        <td><?php echo e($file->region); ?></td>
                        <td><a href="#" class="btn btn-info">نمایش تصویر</a></td>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("show_files")): ?>
                        <td><?php if($file->visible): ?> فعال <?php else: ?> غیرفعال <?php endif; ?> </td>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin_permissions')): ?>
                        <td>
                            <form action="<?php echo e(route('files.destroy', $file)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <div class="btn-group btn-group-xs">
                                    <a href="<?php echo e(route('files.edit', $file)); ?>" class="btn btn-primary">ویرایش</a>
                                    <button type="submit" class="btn btn-danger">حذف</button>
                                </div>
                            </form>
                        </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div style="text-align: center">
            <?php echo $files->render(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\Project\resources\views/Admin/files/all.blade.php ENDPATH**/ ?>