<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('Admin.section.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
        <div class="page-header head-section">
            <h2>فایل</h2>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
            <a href="<?php echo e(route('files.create')); ?>" class="btn btn-sm btn-primary">ایجاد فایل</a>
            <?php echo $__env->make("Admin.files.search", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
        </div>
        <div class="table-responsive">
            <table class="table table-striped table-bordered">
                <thead>
                <tr>
                    <th>نام و نام خانوادگی</th>
                    <th>تلفن</th>
                    <th>آدرس اصلی</th>
                    <th>آدرس فرعی</th>
                    <th>ناحیه</th>
                    <th>کد فایل</th>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("admin","master")): ?>
                        <th>وضعیت</th>
                    <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("master")): ?>
                        <th>کنترل</th>
                <?php endif; ?>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($file->name); ?> <?php echo e($file->lastname); ?></td>
                        <td><?php echo e($file->phonenumber); ?></td>
                        <td><?php echo e($file->addressPu); ?></td>
                        <td><?php echo e($file->addressPv); ?></td>
                        <td><?php echo e($file->region); ?></td>
                        <td><?php echo e($file->code); ?></td>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("admin","master")): ?>
                        <td><?php if($file->visible): ?> فعال <?php else: ?> غیرفعال <?php endif; ?> </td>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('master')): ?>
                        <td>
                            <div class="btn-group btn-group-xs">
                                <form action="<?php echo e(route('files.destroy', $file)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button type="submit" class="btn btn-default">حذف</button>
                                    <a href="<?php echo e(route('files.edit', $file)); ?>" class="btn btn-default">ویرایش</a>
                                    <a href="<?php echo e(route('changeMode', $file)); ?>" class="btn btn-default">تغییر وضعیت</a>
                                    <a href="<?php echo e(route('archive',$file)); ?>" class="btn btn-default">بایگانی</a>
                                    <a href="<?php echo e(route('files.show',$file)); ?>" class="btn btn-default">نمایش جزئیات</a>
                                </form>
                            </div>
                        </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\Project\resources\views/Admin/files/all.blade.php ENDPATH**/ ?>