<?php $agent = auth()->user()->rollId == 0 ? "master" : \App\Agent::where('id',-1*auth()->user()->rollId)->first();  ?>
<?php $__env->startSection('content'); ?>
    <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
        <h1 class="page-header"> سلام <?php echo e($agent->name ?? ""); ?></h1>
        <?php if($agent != "master"): ?>
        <h3 class="title-content"> تعداد ثبتی ها ی شما تا این لحضه : <?php echo e($agent->registered_items); ?></h3>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\Project\resources\views/Admin/panel.blade.php ENDPATH**/ ?>