<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1,shrink-to-fit=no">
    <title>ٌصفحه اصلی</title>
    <link href="<?php echo e(asset("../base/css/index.css")); ?>" rel="stylesheet" type="text/css">
    <link href="../base/css/bootstrap.css" rel="stylesheet" type="text/css">
    <link href="../base/fontawesome/css/all.css" rel="stylesheet" type="text/css">
    <script src="../base/jquery/jquery-3-4-1.js"></script>

</head>

<body class="body">
HelloWorld
</body>
</html>
<?php /**PATH E:\wamp64\www\Project\resources\views/Base/TestView.blade.php ENDPATH**/ ?>