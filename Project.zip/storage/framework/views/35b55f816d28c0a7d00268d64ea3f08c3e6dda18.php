<?php $__env->startSection('content'); ?>
    <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
        <div class="page-header head-section">
            <h2>مشترک ها</h2>
            <a href="<?php echo e(route('members.create')); ?>" class="btn btn-sm btn-primary">ایجاد کاربر</a>
        </div>
        <div class="table-responsive">
            <table class="table table-striped table-bordered">
                <thead>
                <tr>
                    <th>نام املاکی</th>
                    <th>نام نام خانوادگی</th>
                    <th>شماره تماس</th>
                    <th>ناحیه</th>
                    <th>آدرس</th>
                    <th>نوع اشتراک</th>
                    <th>تاریخ اتمام اشتراک</th>
                    <th>تنظیمات</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($customer->office); ?></td>
                        <td><?php echo e($customer->name); ?> <?php echo e($customer->lastname); ?></td>
                        <td><?php echo e($customer->phonenumber); ?></td>
                        <td><?php echo e($customer->region); ?></td>
                        <td><?php echo e($customer->address); ?></td>
                        <?php switch($customer->panel):
                             case (1): ?> <td>یک ماهه</td> <?php break; ?>
                             <?php case (2): ?> <td>سه ماهه</td> <?php break; ?>
                             <?php case (3): ?> <td>شش ماهه</td> <?php break; ?>
                             <?php case (4): ?> <td>یک ساله</td> <?php break; ?>
                             <?php default: ?> <td>بدون اشتراک</td> <?php break; ?>
                        <?php endswitch; ?>
                        <td><?php echo e(verta($customer->expire_subscription) ?? ""); ?></td>
                        <td>
                            <a class="btn btn-default" href="<?php echo e(route('disable.member',$customer)); ?>"> <?php if($customer->enable!=0): ?> غیرفعال <?php else: ?> فعال <?php endif; ?></a>
                            <a class="btn btn-default" href="<?php echo e(route('members.edit',$customer)); ?>"> ویرایش</a>
                            <a class="btn btn-default" href="<?php echo e(route('members.show',$customer)); ?>">  نمایش اطلاعات</a>
                            <a class="btn btn-default" href="<?php echo e(route('resetIp',$customer)); ?>">ریست ip</a>
                            <form action="<?php echo e(route('members.destroy',$customer->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field("delete"); ?>
                                <button class="btn btn-default" type="submit">حذف</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div style="text-align: center">
            <?php echo $customers->render(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\Project\resources\views/Admin/members/all.blade.php ENDPATH**/ ?>