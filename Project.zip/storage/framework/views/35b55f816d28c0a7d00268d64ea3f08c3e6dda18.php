<?php $__env->startSection('content'); ?>
    <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
        <div class="page-header head-section">
            <h2>مشترک ها</h2>
        </div>
        <div class="table-responsive">
            <table class="table table-striped table-bordered">
                <thead>
                <tr>
                    <th>نام نام خانوادگی</th>
                    <th>شماره تماس</th>
                    <th>ناحیه</th>
                    <th>آدرس</th>
                    <th>وضعیت اشتراک</th>
                    <th>نوع اشتراک</th>
                    <th>تاریخ شروع اشتراک</th>
                    <th>دسترسی</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($customer->name); ?> <?php echo e($customer->lastname); ?></td>
                        <td><?php echo e($customer->phonenumber); ?></td>
                        <td><?php echo e($customer->region); ?></td>
                        <td><?php echo e($customer->address); ?></td>
                        <td><?php if($customer->mode == 0): ?> معمولی <?php else: ?> ویژه <?php endif; ?></td>
                        <td><?php echo e($customer['subscribtion-time'] ?? ''); ?></td>
                        <td><?php echo e($customer['start-subscribtion'] ?? ''); ?></td>
                        <td><a href="<?php echo e(route('disable.member',$customer)); ?>"> <?php if($customer->enable==0): ?> غیرفعال <?php else: ?> فعال <?php endif; ?></a> </tr>
                    </td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div style="text-align: center">
            <?php echo $customers->render(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\Project\resources\views/Admin/members/all.blade.php ENDPATH**/ ?>