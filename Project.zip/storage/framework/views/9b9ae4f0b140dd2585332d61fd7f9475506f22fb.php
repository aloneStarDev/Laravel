<?php echo $__env->make('template.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<form action="<?php echo e(route('verify')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <input type="text" name="verify" placeholder="ActivationCode" />
    <input type="text" name="password" placeholder="password" />
    <input type="submit" value="send">
</form>
<?php echo $__env->make('template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH E:\wamp64\www\Project\resources\views/Auth/verify.blade.php ENDPATH**/ ?>